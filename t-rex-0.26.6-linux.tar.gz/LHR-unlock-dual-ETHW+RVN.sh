#!/bin/sh
./t-rex -a ethash --dual-algo kawpow -o stratum+tcp://ethw.2miners.com:2020 -u 0x4121c43205D4244cb6395B2318d711a73fc1a6DE -p x -w rig0 --url2 stratum+tcp://rvn.2miners.com:6060 --user2 RNm4LMBGyfH8ddCGvncQKrMtxEydxwhUJL.rig0 --pass2 x
