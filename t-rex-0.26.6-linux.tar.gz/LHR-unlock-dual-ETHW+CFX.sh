#!/bin/sh
./t-rex -a ethash --dual-algo octopus -o stratum+tcp://pool.woolypooly.com:3096 -u 0x4121c43205D4244cb6395B2318d711a73fc1a6DE -p x -w rig0 --url2 stratum+tcp://pool.woolypooly.com:3094 --user2 cfx:aajauymfc0cpd4aj91wmfyd150avfg3fmym9j2xrh8.rig0 --pass2 x
